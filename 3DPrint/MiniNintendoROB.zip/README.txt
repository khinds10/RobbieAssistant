                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1494964
Mini Nintendo R.O.B. by RabbitEngineering is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

It's R.O.B, the lovable scamp and failed peripheral for Nintendo's Famicom/NES! Don't feel too bad for him, he got a reprisal in Smash Bros. Print this one out in US or Japanese colors, or get creative! This little model is posable - adjust the shoulder height, head angle, and swivel the arms!

Modeled completely in OpenSCAD using primitives and booleans, which was quite a job, let me tell you - 3000 lines of code to make the little guy.

# Post-Printing

## Instructions

HOW TO PRINT:
- Parts that have BLK in the front of the name should be printed in black
- Parts that have x2 at the back of the name should be printed twice.

ASSEMBLY:
Paint everything first in the colors you want - once you assemble it will be much harder to paint

Arms:
1. glue a wrist to a hand (the square side of wrist inserts into the square opening in the hand; then repeat for the other hand
2. Sandwich the wrist between two arms halves (place the wrist round peg into the smaller of the holes in the arms); you will add a little superglue to each of the raised square sections in the middle of the arm, and then mate those two pieces. You should end up with the wrst freely swiveling in the sandwich. Repeat this for the other arm.

Shoulders:
1. Sandwich the completed arms between the two shoulder pieces (place the larger arm hole into the pegs on the shoulder pieces); Glue the top and bottom shoulder parts, but ensure that the arms can swivel freely.

Base/Body:
1. Glue the base bottom to the base top (it's modeled in two parts so you can easily paint them different colors).

Head:
1. Paint one flat end BLK_eyesbase.stl red/pink
2. Glue BLK_eyes.stl over the face you just painted red, so that you can see the red through the eye holes.

FINAL ASSEMBLY:
*** BE CAREFUL WITH THE ARMS! They are quite delicate. Apply force only to the shoulders themselves.
1. Slide shoulders onto the base peg, and secure it using shoulder_peg.stl at the height you want.
2. Attach the head to the base peg - it should rotate from side to side.

If you want extreme realism, coil up a little piece of hookup cable around a pencil, and glue it to the base and shoulders to simulated the cable.